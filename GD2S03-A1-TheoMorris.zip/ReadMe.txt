The controls for the game is touch the screen and you player will fly upwards,
your goal is to reach the furthest distance you can and avoid the lasers

music used is from https://davidkbd.itch.io/interstellar-edm-metal-music-pack